// Dto of Speacialization

    public class SpecializationDto
    {
        public int specializationId { get; set; }
        public string specializationName { get; set; } = string.Empty;
    }
