﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Fracto_Backend.Migrations
{
    /// <inheritdoc />
    public partial class CreateSpecializationsNew : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
