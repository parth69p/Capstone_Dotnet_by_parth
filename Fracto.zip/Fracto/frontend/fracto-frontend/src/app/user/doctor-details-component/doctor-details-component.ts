import { Component } from '@angular/core';

@Component({
  selector: 'app-doctor-details-component',
  imports: [],
  templateUrl: './doctor-details-component.html',
  styleUrl: './doctor-details-component.css'
})
export class DoctorDetailsComponent {
 
}
