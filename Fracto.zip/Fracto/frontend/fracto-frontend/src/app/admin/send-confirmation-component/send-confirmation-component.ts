import { Component } from '@angular/core';

@Component({
  selector: 'app-send-confirmation-component',
  imports: [],
  templateUrl: './send-confirmation-component.html',
  styleUrl: './send-confirmation-component.css'
})
export class SendConfirmationComponent {

}
