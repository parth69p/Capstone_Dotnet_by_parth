import { Component } from '@angular/core';

@Component({
  selector: 'app-admin-dashboard-component',
  templateUrl: './admin-dashboard-component.html',
  styleUrls: ['./admin-dashboard-component.css']
})
export class AdminDashboardComponent {

}
